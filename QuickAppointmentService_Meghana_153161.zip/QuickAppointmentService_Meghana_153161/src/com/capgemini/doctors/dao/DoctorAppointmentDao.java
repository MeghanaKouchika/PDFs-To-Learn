package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASException;
import com.capgemini.doctors.util.DBUtil;

public class DoctorAppointmentDao implements IDoctorAppointmentDao 
{
	//private Map<Integer, DoctorAppointment> patients  = new HashMap<Integer, DoctorAppointment>();
	
	Map<Integer,DoctorAppointment> patients;
	DBUtil dbUtil = new DBUtil();
	
	//constructor
	public DoctorAppointmentDao() 
	{
		patients = dbUtil.getPatients();
	}
	
	
	private Map<String, String> doctors  = new HashMap<String, String>();
	
	{
		doctors.put("Heart", "Dr. Brijesh Kumar");
		doctors.put("Gynecology", "Dr. Sharda Singh");
		doctors.put("Diabetes", "Dr. Heena Khan");
		doctors.put("ENT", "Dr. Paras mal");
		doctors.put("Bone", "Dr. Renuka Kher");
		doctors.put("Dermatology", "Dr. Kanika Kapoor");
		
	}	
	
	
	public int generateRandomId()
	{
		double rndDouble = Math.random();
		
		return (int)(rndDouble * 10000);
	}
	
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws QASException 
	{
		int id = generateRandomId();
		
		doctorAppointment.setAppointmentId(id);
		
		//adding patient details to HashMap
		patients.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		
		//checking whether there is doctor available for the problem or not
		if(doctors.get(doctorAppointment.getProblemName()) != null) 
		{
			//if available set the appointment status approved and set the doctor name
			doctorAppointment.setAppointmentStatus("APPROVED");
			doctorAppointment.setDoctorName(doctors.get(doctorAppointment.getProblemName()));
		}
		
		//return the id through which the appointment object is stored in the HashMap
		return doctorAppointment.getAppointmentId();
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) throws QASException 
	{
		if(appointmentId <= -1) throw new QASException("Please enter Valid Id");
		
		DoctorAppointment appointment = patients.get(appointmentId);
		if(appointment.getDoctorName() == null) throw new QASException("There is no doctor available to your problem");
		
		return appointment;
	}

}
