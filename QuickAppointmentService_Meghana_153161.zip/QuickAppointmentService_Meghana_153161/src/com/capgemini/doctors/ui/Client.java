package com.capgemini.doctors.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class Client 
{
	IDoctorAppointmentService appointmentService;
	
	public Client() 
	{
		appointmentService = new DoctorAppointmentService();
		
	}
	
	public static void main(String[] args) 
	{
		Client client = new Client();
		
		while(true) 
		{
			client.menu();
			
		}
		
	}

	public void menu() 
	{
		System.out.println("1)Book Doctor Appointment");
		System.out.println("2)View Doctor Appointment");
		System.out.println("3)Exit");
		System.out.print("\nEnter the choice: ");	
		
		operation();	
	}

	public void operation() 
	{
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice) 
		{
			case 1:
				bookAppointment();
				break;
			case 2:
				viewAppointment();
				break;
			case 3:
				System.out.println("Thank you for using Quick Appointment Service Application");
				System.out.println("Visit Again");
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid option");
				break;
		}
		
	}

	public void bookAppointment() 
	{
		Scanner sc = new Scanner(System.in);
		
		//patient Details from the console
		
		System.out.print("Enter Name of the patient : ");
		String patientName = sc.next();

		System.out.print("Enter Phone Number : ");
		long phoneNumber = sc.nextLong();
		
		System.out.print("Enter Email : ");
		String email = sc.next();
		
		System.out.print("Enter Age : ");
		int age = sc.nextInt();
		
		System.out.print("Enter Gender : ");
		String gender = sc.next();
		
		System.out.print("Enter problem Name : ");
		String problemName = sc.next();
		
		DoctorAppointment appointment = new DoctorAppointment();
		appointment.setPatientName(patientName);
		appointment.setPhoneNumber(phoneNumber);
		appointment.setEmail(email);
		appointment.setAge(age);
		appointment.setGender(gender);
		appointment.setAppointmentDate(LocalDate.now());
		appointment.setProblemName(problemName);
		
		try 
		{
			int id = appointmentService.addDoctorAppointmentDetails(appointment);
			
			System.out.println("\nYour Doctor Appointment has been successfully registered, your appointment ID is: "+id+"\n");
			
			
		} 
		catch (QASException e) 
		{
			System.out.println("\n" + e.getMessage() + "\n");
		}
		catch(Exception e)
		{
			System.out.println("There is some issue... Come Again");;
		}
		
		
		
	}

	public void viewAppointment() 
	{
		
		DoctorAppointment appointment = new DoctorAppointment();
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the appointment Id : ");
		int appointmentId = sc.nextInt();
		
		try 
		{
			appointment = appointmentService.getDoctorAppointmentDetails(appointmentId);
			
			System.out.println("\nPatient Name\t   :" + appointment.getPatientName());
			System.out.println("Appointment Status:" + appointment.getAppointmentStatus());
			System.out.println("Doctor Name\t   :" + appointment.getDoctorName());
			System.out.println("Appoinment Date and time, along with doctor's phone number will be shared shortly with you\n");
			
		} 
		catch (QASException e) 
		{
			System.out.println("\n" +e.getMessage() + "\n");
		}
		catch(Exception e)
		{
			System.out.println("\n There is some issue in the server.. Please visit later");
		}
		
		
	}

}
