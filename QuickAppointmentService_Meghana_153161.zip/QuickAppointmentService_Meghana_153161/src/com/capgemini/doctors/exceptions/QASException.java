package com.capgemini.doctors.exceptions;

public class QASException extends Exception
{

	public QASException() 
	{
		super();
	}

	public QASException(String arg0, Throwable arg1, boolean arg2, boolean arg3) 
	{
		super(arg0, arg1, arg2, arg3);
	}

	public QASException(String arg0, Throwable arg1) 
	{
		super(arg0, arg1);
	}

	public QASException(String arg0) 
	{
		super(arg0);
	}

	public QASException(Throwable arg0) 
	{
		super(arg0);
	}
	

}
