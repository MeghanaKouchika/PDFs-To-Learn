package com.capgemini.doctors.util;

import java.util.*;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DBUtil 
{
	private Map<Integer, DoctorAppointment> patients  = new HashMap<Integer, DoctorAppointment>();
	{
		
	}


	public Map<Integer, DoctorAppointment> getPatients() {
		return patients;
	}


	public void setPatients(Map<Integer, DoctorAppointment> patients) {
		this.patients = patients;
	}
	
	
}
