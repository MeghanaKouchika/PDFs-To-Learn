package com.capgemini.doctors.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exceptions.QASException;
import com.capgemini.doctors.service.DoctorAppointmentService;
import com.capgemini.doctors.service.IDoctorAppointmentService;

public class TestApplicationService {

	static IDoctorAppointmentService appointmentService;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception 
	{
		appointmentService = new DoctorAppointmentService();
	
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddDoctorAppointmentDetails() throws QASException {
		DoctorAppointment appointment = new DoctorAppointment();
		appointment.setPatientName("Meghana");
		appointment.setPhoneNumber(7095134616l);
		appointment.setEmail("meghana.kouchika@gmail.com");
		appointment.setAge(23);
		appointment.setGender("Female");
		appointment.setProblemName("Heart");
		
		int appointmentRequestId = appointmentService.addDoctorAppointmentDetails(appointment);
		assertTrue( appointmentRequestId > 0 );
	}

	@Test
	public void testGetDoctorAppointmentDetails() throws QASException {
		DoctorAppointment appointment = new DoctorAppointment();
		
		appointment.setPatientName("Eric");
		appointment.setPhoneNumber(9898989898L);
		appointment.setEmail("eric@gmail.com");
		appointment.setGender("Male");
		appointment.setAge(32);
		appointment.setProblemName("Heart");
		
		int appointmentRequestId = appointmentService.addDoctorAppointmentDetails(appointment);
		
		DoctorAppointment appointment2 = appointmentService.getDoctorAppointmentDetails( appointmentRequestId );
		
		assertNotEquals(null, appointment2);
	}
	
	//when get method does not work
	@Test(expected=QASException.class)
	public void testGetDoctorAppointmentDetails2() throws QASException
	{
		DoctorAppointment appointment = appointmentService.getDoctorAppointmentDetails(-1000);
		
	}
	
	
	//when the add function does not work
	@Test(expected=QASException.class)
	public void testEmailValidation() throws QASException 
	{
	DoctorAppointment appointment = new DoctorAppointment();
		
		appointment.setPatientName("Eric");
		appointment.setPhoneNumber(9898989898L);
		appointment.setEmail("ericgmail.com");
		appointment.setGender("Male");
		appointment.setAge(32);
		appointment.setProblemName("Heart");
		
		appointmentService.addDoctorAppointmentDetails( appointment );
	}
}
