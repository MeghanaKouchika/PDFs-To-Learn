package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.dao.IDoctorAppointmentDao;
import com.capgemini.doctors.exceptions.QASException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	IDoctorAppointmentDao dao;
	
	public DoctorAppointmentService() 
	{
		dao = new DoctorAppointmentDao();
	}
	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) throws QASException 
	{	
		if(isValid(doctorAppointment)) return dao.addDoctorAppointmentDetails(doctorAppointment);
		
		return 0;
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws QASException 
	{
		if(dao.getAppointmentDetails(appointmentId) == null) throw new QASException("There is no appointment ID");
		return dao.getAppointmentDetails(appointmentId);
	}
	@Override
	public boolean isValid(DoctorAppointment appointment) throws QASException 
	{
		if( appointment == null)
			throw new QASException( "Appointment instance cannot be null" );
		
		if( appointment.getPatientName() == null || appointment.getPatientName().trim().isEmpty() )
			throw new QASException( "Patient Name Cannot be Empty" );
		
		if( appointment.getPhoneNumber() == 0 ||  isPhoneNumberInvalid( appointment.getPhoneNumber() ) )
			throw new QASException( "Phone Number is invalid" );
		
		if( appointment.getEmail() == null || isEmailInvalid( appointment.getEmail() ) )
			throw new QASException( "Email has to be a valid email" );
		
		if( !(appointment.getAge() > 1 && appointment.getAge() <= 120) )
			throw new QASException( "Age has to be between 1 to 120" );
		
		if( appointment.getGender() == null || isGenderInvalid( appointment.getGender() ) ) 
			throw new QASException( "Gender can only be Male or Female" );
		
		if( appointment.getProblemName() == null ||  appointment.getProblemName().trim().isEmpty() )
			throw new QASException( "Problem cannot be blank" );
		
		return true;
	}

	public static boolean isGenderInvalid(String gender) 
	{
		gender = gender.toLowerCase();
		
		if( !gender.matches("^male$|^female$"))
			return true;	
		else
			return false;
	}
	
	public boolean isEmailInvalid( String email ) {
		
		if( email.matches(".+\\@.+\\..+") ) 
		{
			return false;
		}		
		else 
			return true;
	}

	public static boolean isPhoneNumberInvalid( long phoneNumber )
	{
		if(String.valueOf(phoneNumber).matches("[1-9][0-9]{9}")) 
		{
			return false;
		}		
		else 
			return true;
	}
	
	
}
