package com.capgemini.core.ems.model;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeDAOImpl implements EmployeeDAO 
{

	List<Employee> employees;
	
	public EmployeeDAOImpl() {
		employees = new ArrayList<Employee>();
	}
	
	@Override
	public int addEmployee(Employee employee) throws EMSException {
		
		int employeeId = 0;
		
		try(Connection con = DBUtil.getConnection())
		{
			Statement stm = con.createStatement();
			ResultSet res = stm.executeQuery("select empId_seq.nextVal from dual");
			
			if(res.next() == false)
				throw new EMSException("Could not generate employee id");
			
			employeeId = res.getInt(1);
			
			employee.setId(employeeId);
			
			PreparedStatement pstm = con.prepareStatement("insert into employee values(?,?,?,?,?,?)");
			
			pstm.setInt(1, employee.getId());
			pstm.setString(2, employee.getName());
			pstm.setDouble(3,employee.getSalary());
			pstm.setString(4, employee.getDepartment());
			pstm.setDate(5, new java.sql.Date(employee.getDateOfBirth().getTime()));
			pstm.setDate(6, new java.sql.Date(employee.getDateOfJoining().getTime()));
			
			//pstm.execute();
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return employeeId;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {
		
		Employee emp = null;
		
		try(Connection con = DBUtil.getConnection()) 
		{
			PreparedStatement pstm = con.prepareStatement("select * from Employee where id = ?");
			
			pstm.setInt(1, id);
			
			ResultSet res = pstm.executeQuery();
			
			if(res.next() == false)
				throw new EMSException("No employee with id " + id);
			
			emp = new Employee();
			emp.setId(res.getInt(1));
			emp.setName(res.getString(2));
			emp.setSalary(res.getDouble(3));
			emp.setDepartment(res.getString(4));
			emp.setDateOfBirth(res.getDate(5));
			emp.setDateOfJoining(res.getDate(6));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return emp;
	}

	@Override
	public void updateEmployee(Employee employee) throws Exception {
		try(Connection con = DBUtil.getConnection()) 
		{
			PreparedStatement pstm = con.prepareStatement("update employee set name = ?, salary = ?, department = ?, dateofbirth = ?, dateofjoining = ? where id = ?");
			
			pstm.setString(1, employee.getName());
			pstm.setDouble(2, employee.getSalary());
			pstm.setString(3, employee.getDepartment());
			pstm.setDate(4, new java.sql.Date(employee.getDateOfBirth().getTime()));
			pstm.setDate(5, new java.sql.Date(employee.getDateOfJoining().getTime()));
			pstm.setInt(6, employee.getId());
			
			pstm.execute();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public Employee removeEmployee(int id) throws EMSException {
		Employee employee = getEmployee(id);
		try(Connection con = DBUtil.getConnection()) 
		{
			PreparedStatement pstm = con.prepareStatement("delete from employee where id = ?");
			
			pstm.setInt(1, id);
			
			pstm.execute();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		try(Connection con = DBUtil.getConnection()) 
		{
			Statement stm = con.createStatement();
		
			ResultSet rs = stm.executeQuery("select * from employee");	
			
			int index = 0;
			while(rs.next()) {
				Employee employee = new Employee();
				employee.setId(rs.getInt(1));
				employee.setName(rs.getString(2));
				employee.setSalary(rs.getDouble(3));
				employee.setDepartment(rs.getString(4));
				employee.setDateOfBirth(rs.getDate(5));
				employee.setDateOfJoining(rs.getDate(6));
				
				employees.add(employee);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return employees;
	}
	
}
