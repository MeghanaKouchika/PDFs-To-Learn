package com.capgemini.core.ems.service;

import java.util.List;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.model.EmployeeDAO;
import com.capgemini.core.ems.model.EmployeeDAOImpl;
import com.capgemini.core.ems.util.DBUtil;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDAO empDAO;

	public EmployeeServiceImpl() 
	{
		empDAO = new EmployeeDAOImpl(); 
	}


	@Override
	public int addEmployee(Employee employee) throws EMSException {

		int empId = 0;

		if( isValid(employee) ) {
			empId = empDAO.addEmployee(employee);
		}
		return empId;
	}

	@Override
	public Employee getEmployee(int id) throws EMSException {
		
		Employee employee = null;
		
		employee = empDAO.getEmployee(id);
		
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws Exception {
		// TODO Auto-generated method stub
		
		empDAO.updateEmployee(employee);

	}

	@Override
	public Employee removeEmployee(int id) throws EMSException {
		
		Employee employee = null;
		
		employee = empDAO.removeEmployee(id);
		
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		// TODO Auto-generated method stub
		
		List<Employee> employees = null;
		employees = empDAO.getAllEmployees();
		
		return employees;
	}

	@Override
	public boolean isValid(Employee employee) throws EMSException {
		
		//validation code
		
		return true;
	}

}
