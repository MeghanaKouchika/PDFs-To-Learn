package com.capgemini.core.lms.service;

import java.util.List;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.core.lms.exception.LMSException;

public interface LMSService 
{
	public int addBook(Book book) throws LMSException;
	
	public Book getBook(int bookId) throws LMSException;
	
	public void updateBook(Book book) throws LMSException;
	
	public Book removeBook(int bookId) throws LMSException;
	
	public List<Book> getBooks() throws LMSException;

}
