package com.capgemini.core.lms.view;

import java.util.Scanner;

import com.capgemini.core.lms.bean.Book;
import com.capgemini.core.lms.exception.LMSException;
import com.capgemini.core.lms.service.LMSService;
import com.capgemini.core.lms.service.LMSServiceImpl;

public class Client 
{
	LMSService service;
	
	public Client() 
	{
		service = new LMSServiceImpl();
	}
	
	
	public void menu() 
	{
		System.out.println("1) Add Book");
		System.out.println("2) Get Book with id");
		System.out.println("3) Update Book");
		System.out.println("4) Remove Book");
		System.out.println("5) Get all books");
		System.out.println("6) Exit the application");
		
		operation();
	}
	
	public void operation() {
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice) {
			case 1:
				addBook();
				break;
			case 2:
				getBook();
				break;
			case 3:
				updateBook();
				break;
			case 4:
				removeBook();
				break;
			case 5:
				allBooks();
				break;
			case 6:
				System.out.println("Thank you for using this application");
				System.exit(0);
			default:
				break;
		}
	}
	
	private void addBook() 
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter title Name: ");
		String bookName = sc.nextLine();
		
		System.out.println("Enter author Name");
		String authorName = sc.nextLine();
		
		System.out.println("Enter the price");
		float price = Float.parseFloat(sc.nextLine());
		
		Book book = new Book();
		book.setTitle(bookName);
		book.setAuthor(authorName);
		book.setPrice(price);
	//	Book book = new Book(bookName, authorName, price);\
		
		try 
		{
			int id = service.addBook(book);
			System.out.println("The book you added has got id " + id);
		}
		catch (LMSException e) 
		{
			e.printStackTrace();
		}
		
		
	}


	private void allBooks() {
		try 
		{
			System.out.println(service.getBooks());
		} 
		catch (LMSException e) 
		{
			e.printStackTrace();
		}
		
	}


	private void removeBook() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id of the book to be removed");
		int id = sc.nextInt();
		try 
		{
			Book book = service.removeBook(id);
			System.out.println(book);
		} 
		catch (LMSException e) 
		{
			e.printStackTrace();
		}
	}


	private void updateBook() {
		
		
	}


	private void getBook() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id to get the info");
		int id = sc.nextInt();
		try 
		{
			Book book = service.getBook(id);
			System.out.println(book);
		}
		catch (LMSException e) 
		{
			e.printStackTrace();
		}
		
		
	}

	public static void main(String[] args) 
	{
		Client client = new Client();
		while(true) 
			client.menu();
	}
}
