package com.capgemini.service;

import com.capgemini.model.OrderDetails;

public interface UpdateStatus {

	public void setId(OrderDetails order);
	public String updateDetails();
	
	
}
