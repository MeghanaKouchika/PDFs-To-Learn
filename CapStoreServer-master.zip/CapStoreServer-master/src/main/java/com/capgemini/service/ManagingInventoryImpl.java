package com.capgemini.service;

import java.util.List;

import com.capgemini.model.Category;
import com.capgemini.model.Product;

public class ManagingInventoryImpl implements IManagingInventory{

	@Override
	public List<Product> displayListOfProducts(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product addNewProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product editExistingProductDetails(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeExistingProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int displayStockCount(Product product) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void updatingStockCount(int count) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Category> displayListOfCategories(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Category addNewCategory(Category category) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeExistingCategory(Category category) {
		// TODO Auto-generated method stub
		
	}

}
