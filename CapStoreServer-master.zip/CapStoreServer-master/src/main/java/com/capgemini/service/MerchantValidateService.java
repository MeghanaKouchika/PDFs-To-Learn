package com.capgemini.service;

import com.capgemini.model.Merchant;

public interface MerchantValidateService {

	public Merchant merchantValidation();
}
