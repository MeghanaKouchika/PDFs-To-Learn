package com.capgemini.service;

public interface ManagingMerchantService {
public void AddMerchant();
public void DeleteMerchant();
public void UpdateMerchant();
}
