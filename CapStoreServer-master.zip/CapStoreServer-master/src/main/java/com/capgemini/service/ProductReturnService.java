package com.capgemini.service;

import com.capgemini.model.OrderDetails;

public interface ProductReturnService {
	OrderDetails returnProduct(OrderDetails orderDetails);
}
