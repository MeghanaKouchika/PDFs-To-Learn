package com.capgemini.service;

import com.capgemini.repository.UserRepository;

public class ManagingMerchantImpl implements ManagingMerchantService {

	public ManagingMerchantImpl(UserRepository userrepo) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void AddMerchant() {
		
		
	}

	@Override
	public void DeleteMerchant() {
		
		
	}

	@Override
	public void UpdateMerchant() {
		
		
	}

}
