package com.capgemini.service;

import com.capgemini.model.Product;

public interface UserFeedBackService {
	public Product getFeedback(int id);

}
