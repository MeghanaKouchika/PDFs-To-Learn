package com.capgemini.core.ems.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.capgemini.core.ems.beans.Employee;

public class DBUtil 
{
	List<Employee> employees = new ArrayList<Employee>();
	
	{
		Random rand = new Random();
		employees.add( new Employee(1,"Alekhya", 23000, "IT", null, null));
		//add 5-6 more employees
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
}
