package com.capgemini.core.ems.model;

import java.util.List;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;

public interface EmployeeDAO 
{
	//Data Access Object
	public int addEmployee(Employee employee) throws EMSException; // adds the object and returns id which should be stored to access that particular row
	
	public Employee getEmployee(int id) throws EMSException; //gives particular object based on the id
	
	public void updateEmployee(Employee employee) throws Exception; //should give all the details about employee to update the previous details
	
	public Employee removeEmployee(int id) throws EMSException; //what has been removed should be shown
	
	public List<Employee> getAllEmployees() throws EMSException; //should print all the employees
	
	public void startTransaction();
	
	public void commitTransaction();
}
