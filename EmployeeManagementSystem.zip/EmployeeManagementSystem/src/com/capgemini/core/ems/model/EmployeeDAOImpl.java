package com.capgemini.core.ems.model;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.util.DBUtil;
import com.capgemini.core.ems.util.JPAUtil;

public class EmployeeDAOImpl implements EmployeeDAO 
{
	
	private EntityManager entityManager;
	
	public EmployeeDAOImpl() 
	{
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addEmployee(Employee employee) throws EMSException 
	{
		try {
			//id will be assigned when object is passed to persist
			entityManager.persist(employee);
			//entityManager.flush();
		}
		catch(Exception e)
		{
			throw new EMSException(e.getMessage());
		}
		
		return employee.getId();
	}

	@Override
	public Employee getEmployee(int id) throws EMSException 
	{
		Employee employee = entityManager.find(Employee.class, id);
		return employee;
	}

	@Override
	public void updateEmployee(Employee employee) throws Exception 
	{
		entityManager.merge(employee);
	}

	@Override
	public Employee removeEmployee(int id) throws EMSException 
	{
		Employee employee = getEmployee(id);
		entityManager.remove(employee);
		return employee;
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException 
	{
		Query query = entityManager.createNamedQuery("getAllEmployees");
		
		@SuppressWarnings("unchecked")
		
		List<Employee> employees = query.getResultList();
		return employees;
	}

	@Override
	public void startTransaction() 
	{
		entityManager.getTransaction().begin();
		
	}

	@Override
	public void commitTransaction() 
	{
		entityManager.getTransaction().commit();
		
	}
	
}
