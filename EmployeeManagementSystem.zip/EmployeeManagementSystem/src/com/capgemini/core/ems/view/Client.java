package com.capgemini.core.ems.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.ems.beans.Employee;
import com.capgemini.core.ems.exceptions.EMSException;
import com.capgemini.core.ems.service.EmployeeService;
import com.capgemini.core.ems.service.EmployeeServiceImpl;

public class Client 
{
	//loose coupling due to the use of interface reference
	private EmployeeService employeeService;
	
	public Client() 
	{
		//association linking to service
		employeeService = new EmployeeServiceImpl();
	}
	
	public Date convertToDate(String date) {
		if(date == null) {
			return null;
		}
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate date1 = LocalDate.parse(date,formatter);
		
		//convert localdate to date
		java.util.Date date2 = java.sql.Date.valueOf(date1);
		return date2;
	}
	
	public void menu()
	{
		System.out.println("1) ADD Employee Information");
		System.out.println("2) GET Employee Information");
		System.out.println("3) UPDATE Employee Information");
		System.out.println("4) REMOVE Employee Information");
		System.out.println("5) VIEW all the employees Information");
		System.out.println("0) EXIT Application");
		
		System.out.println("Please SELECT an option");
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch(choice) {
		case 1:
			Employee employee = new Employee();
			
		//	Scanner sc1;
			System.out.println("1) Enter Employee Name: ");
			String name = sc.next();
			
			System.out.println("2) Enter Employee Salary: ");
			double salary = sc.nextDouble();
			
			System.out.println("3) Enter Employee Department: ");
			String department = sc.next();
			
			System.out.println("4) Enter Employee Date of Birth (dd-mm-yyyy): ");
			String dateOfBirthStr = sc.next();
			
			System.out.println("5) Enter Employee Date of Joining (dd-mm-yyyy): ");
			String dateOfJoiningStr = sc.next();
			
			employee.setName(name);
			employee.setSalary(salary);
			employee.setDepartment(department);
			employee.setDateOfBirth(convertToDate(dateOfBirthStr));
			employee.setDateOfJoining(convertToDate(dateOfJoiningStr));
			
			try 
			{
				int empId = employeeService.addEmployee(employee);
				System.out.println("Employee added Successfully. Employee ID: " + empId);
			} 
			catch (EMSException e) 
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
			
		case 2:
			System.out.println("Enter Employee id to view details: ");
			int id = sc.nextInt();
			
			try 
			{
				employee = employeeService.getEmployee(id);
				
				System.out.println("The employee you wanted to view is ");
				
				System.out.println(employee.getId()+ "\t" + 
						employee.getName() + "\t" + 
								employee.getSalary()+ "\t" + 
						employee.getDepartment() + "\t" + 
								employee.getDateOfBirth()+ "\t" + 
						employee.getDateOfJoining()+ "\t"  );
			} 
			catch (EMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		
			break;
			
		case 3:
			//get employee details if exists
			System.out.println("Enter Employee id to update details: ");
			id = sc.nextInt();
			
			try 
			{
				employee = employeeService.getEmployee(id);
				
				//update name
				System.out.println("Employee Name: " + employee.getName());
				System.out.println("Do you want to update the name: yes/no");
				String reply = sc.next();
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("Enter new Name: ");
					name = sc.next();
					employee.setName(name);
				}
				
				
				//update salary
				System.out.println("Employee Name: " + employee.getSalary());
				System.out.println("Do you want to update the salary: yes/no");
				reply = sc.next();
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("Enter Employee Salary: ");
					salary = sc.nextDouble();
					employee.setSalary(salary);
				}
				
				
				//update department
				System.out.println("Employee Name: " + employee.getDepartment());
				System.out.println("Do you want to update the Department: yes/no");
				reply = sc.next();
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("Enter Employee Department: ");
					department = sc.next();
					employee.setDepartment(department);
				}
				
				
				//update date of birth
				System.out.println("Employee Name: " + employee.getDateOfBirth());
				System.out.println("Do you want to update the Date of Birth: yes/no");
				reply = sc.next();
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("Enter Employee Date of Birth (dd-mm-yyyy): ");
					dateOfBirthStr = sc.next();
					employee.setDateOfBirth(convertToDate(dateOfBirthStr));;
				}
				
				
				//update date of joining
				System.out.println("Employee Name: " + employee.getDateOfJoining());
				System.out.println("Do you want to update the Date of Joining: yes/no");
				reply = sc.next();
				if(reply.equalsIgnoreCase("yes")) {
					System.out.println("Enter Employee Date of Joining (dd-mm-yyyy): ");
					dateOfJoiningStr = sc.next();
					employee.setDateOfJoining(convertToDate(dateOfJoiningStr));
				}
				
			} 
			catch (EMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}			
			break;
			
		case 4:
			System.out.println("Enter Employee id to Delete Employee Details: ");
			id = sc.nextInt();
			
			try 
			{
				employee = employeeService.removeEmployee(id);
				
				System.out.println("The employee deleted from the list is ");
				
				System.out.println(employee.getId()+ "\t" + 
						employee.getName() + "\t" + 
								employee.getSalary()+ "\t" + 
						employee.getDepartment() + "\t" + 
								employee.getDateOfBirth()+ "\t" + 
						employee.getDateOfJoining()+ "\t"  );
			} 
			catch (EMSException e) {
				e.printStackTrace();
			}
			break;
			
		case 5:
			
			try {
				List<Employee> employees = null;
				
				employees = employeeService.getAllEmployees();
				
				Iterator<Employee> it = employees.iterator();
				
				System.out.println("ID \tName \tSalary \tDepartment \tDateOFBirth \tDateOfJoining");
				
				while(it.hasNext()) 
				{
					Employee emp = it.next();
					System.out.println(emp.getId()+ "\t" + 
					emp.getName() + "\t" + 
							emp.getSalary()+ "\t" + 
					emp.getDepartment() + "\t" + 
							emp.getDateOfBirth()+ "\t" + 
					emp.getDateOfJoining()+ "\t"  );
				}
				
			}
			catch (EMSException e) 
			{
				e.printStackTrace();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			break;
			
		case 0:
			System.out.println("Goodbye");
			System.exit( 0 );
			break;
			
		default:
			System.out.println("Invalid Option");
			break;
		}
		
	}
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("log4j.properties");
		
		Client client = new Client();
		
		//makes sure application runs forever unless you close it
		while(true)
			client.menu();	
	}

}
