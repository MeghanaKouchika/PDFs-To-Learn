package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client 
{	
	public static void main(String[] args) 
	{
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		//create one person
		Person person = new Person();
		person.setFirstName("meghana");
		person.setLastName("Kouchika");
		person.setGender("Female");
		em.persist(person);
		
		//create one employee
		Employee employee = new Employee();
		employee.setFirstName("Jaya");
		employee.setLastName("Kancheti");
		employee.setGender("Female");
		employee.setDepartmentName("IT");
		em.persist(employee);
		
		
		//create one vehicle
		Vehicle vehicle = new Vehicle();
		vehicle.setName("Honda");
		vehicle.setFuelType("Petrol");
		vehicle.setVehicleType("2-Wheeler");
		em.persist(vehicle);
		
		//create one manager
		Manager manager = new Manager();
		manager.setFirstName("Deepika");
		manager.setLastName("Korla");
		manager.setGender("Female");
		manager.setDepartmentName("HR");
		manager.setAllowance("ALLOWED");
		manager.setVehicle(vehicle);
		em.persist(manager);
		
		em.getTransaction().commit();
		
		System.out.println("Added one person, vehicle, employee and manager to database.");
		em.close();
		factory.close();
	}

}
